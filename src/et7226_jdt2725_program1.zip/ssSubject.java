public class ssSubject {
	public String name;
	public SecurityLevel sL;
	public int tempValue;

	public ssSubject(String name, SecurityLevel sL, int tempValue) {
		this.name = name;
		this.sL = sL;
		this.tempValue = tempValue;
	}
}
