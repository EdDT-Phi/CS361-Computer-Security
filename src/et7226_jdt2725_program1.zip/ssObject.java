public class ssObject {
	public String name;
	public SecurityLevel sL;
	public int intValue;

	public ssObject(String name, SecurityLevel sL, int intValue) {
		this.name = name;
		this.sL = sL;
		this.intValue = intValue;
	}
}